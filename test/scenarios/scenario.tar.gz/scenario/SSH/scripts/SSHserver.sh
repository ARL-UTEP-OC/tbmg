#!/bin/bash
tshark -i eth0 -w ~/scenario/SSH/imn/both/server.pcap&


