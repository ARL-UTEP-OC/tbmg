#!/bin/bash
tshark -i eth0 -w ~/scenario/HTTP/imn/server/server.pcap&
