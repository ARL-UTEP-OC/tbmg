#!/bin/bash
tshark -i eth0 -w ~/scenario/DHCP/imn/both/server.pcap&


