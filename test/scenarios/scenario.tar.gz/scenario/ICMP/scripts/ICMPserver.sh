#!/bin/bash
tshark -i eth0 -w ~/scenario/ICMP/imn/both/server.pcap&

