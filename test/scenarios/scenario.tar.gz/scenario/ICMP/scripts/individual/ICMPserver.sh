#!/bin/bash
tshark -i eth0 -w ~/scenario/ICMP/imn/server/server.pcap&

