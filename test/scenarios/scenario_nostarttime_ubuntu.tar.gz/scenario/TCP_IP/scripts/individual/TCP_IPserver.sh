#!/bin/bash
tshark -i enp0s3 -w ~/scenario/TCP_IP/imn/server/server.pcap&
nc -lp 81
