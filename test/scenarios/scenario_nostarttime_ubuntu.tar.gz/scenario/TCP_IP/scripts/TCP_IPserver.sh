#!/bin/bash
tshark -i enp0s3 -w ~/scenario/TCP_IP/imn/both/server.pcap&
nc -lp 81
