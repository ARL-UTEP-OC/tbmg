#!/bin/bash
tshark -i enp0s3 -w ~/scenario/FTP/imn/server/server.pcap&
twistd ftp -p 21
