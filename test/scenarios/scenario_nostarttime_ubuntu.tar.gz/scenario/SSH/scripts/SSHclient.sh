#!/bin/bash
tshark -i enp0s3 -w ~/scenario/SSH/imn/both/client.pcap&
sleep 1
rm /root/.ssh/known_hosts 
ssh 10.0.0.10
sleep 1


