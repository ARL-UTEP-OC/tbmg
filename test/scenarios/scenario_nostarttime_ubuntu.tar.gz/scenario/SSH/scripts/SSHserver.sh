#!/bin/bash
tshark -i enp0s3 -w ~/scenario/SSH/imn/both/server.pcap&


