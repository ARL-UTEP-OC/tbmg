#!/bin/bash
tshark -i enp0s3 -w ~/scenario/ARP/imn/both/server.pcap&
nc -k -u -l -p 89
