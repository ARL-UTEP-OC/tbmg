#!/bin/bash
tshark -i enp0s3 -w ~/scenario/ARP/imn/client/client.pcap&
sleep 1
echo -n "hello" | nc -u 10.0.0.10 89 &
