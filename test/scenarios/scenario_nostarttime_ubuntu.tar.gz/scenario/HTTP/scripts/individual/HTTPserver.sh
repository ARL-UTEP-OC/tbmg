#!/bin/bash
tshark -i enp0s3 -w ~/scenario/HTTP/imn/server/server.pcap&
