#!/bin/bash
tshark -i enp0s3 -w ~/scenario/HTTP/imn/client/client.pcap &
sleep 6
while true; do wget 10.0.0.10 80; sleep 3; done
