#!/bin/bash
tshark -i enp0s3 -w ~/scenario/SIP/imn/both/server.pcap&
export TERM=xterm
sipp -sn uas
