#!/bin/bash
tshark -i enp0s3 -w ~/scenario/SIP/imn/both/client.pcap&
export TERM=xterm
sleep 3
sipp -sn uac 10.0.0.10
