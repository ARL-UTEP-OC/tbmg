#!/bin/bash
tshark -i enp0s3 -w ~/scenario/SIP/imn/server/server.pcap&
export TERM=xterm
sipp -sn uas
