#!/bin/bash
tshark -i enp0s3 -w ~/scenario/TCP/imn/server/server.pcap&
while true; do echo -n "i'm listener"; sleep 5; done | nc -lp 81
