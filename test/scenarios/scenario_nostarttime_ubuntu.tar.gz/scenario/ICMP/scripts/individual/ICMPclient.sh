#!/bin/bash
tshark -i enp0s3 -w ~/scenario/ICMP/imn/client/client.pcap&
sleep 1
ping 10.0.0.10
