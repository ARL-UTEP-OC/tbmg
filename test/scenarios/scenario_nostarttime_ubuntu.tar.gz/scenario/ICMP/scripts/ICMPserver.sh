#!/bin/bash
tshark -i enp0s3 -w ~/scenario/ICMP/imn/both/server.pcap&

