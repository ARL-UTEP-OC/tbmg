#!/bin/bash
tshark -i enp0s3 -w ~/scenario/Telnet/imn/server/server.pcap &
twistd inetd
