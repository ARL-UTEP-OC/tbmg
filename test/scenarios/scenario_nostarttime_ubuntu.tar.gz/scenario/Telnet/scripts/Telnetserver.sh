#!/bin/bash
tshark -i enp0s3 -w ~/scenario/Telnet/imn/both/server.pcap &
twistd inetd
