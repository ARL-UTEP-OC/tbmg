#!/bin/bash
tshark -i enp0s3 -w ~/scenario/RTP/imn/client/client.pcap&
sleep 1
cvlc rtp://239.255.12.42
