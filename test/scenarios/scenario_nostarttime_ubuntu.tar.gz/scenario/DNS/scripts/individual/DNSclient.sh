#!/bin/bash
tshark -i enp0s3 -w ~/scenario/DNS/imn/client/client.pcap&
sleep 1
while true; do dig @10.0.0.10 localhost; sleep 3; done
