#!/bin/bash
tshark -i enp0s3 -w ~/scenario/DNS/imn/both/server.pcap&
service bind9 restart
