#!/bin/bash
tshark -i enp0s3 -w ~/scenario/NTP/imn/both/server.pcap&
/etc/init.d/ntp restart
