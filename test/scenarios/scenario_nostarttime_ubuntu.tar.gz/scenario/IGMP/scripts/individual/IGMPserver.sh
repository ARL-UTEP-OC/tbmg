#!/bin/bash
tshark -i enp0s3 -w ~/scenario/IGMP/imn/server/server.pcap&
sleep 1
ip route add 224.225.1/24 dev enp0s3
mgen input test2.mgn
