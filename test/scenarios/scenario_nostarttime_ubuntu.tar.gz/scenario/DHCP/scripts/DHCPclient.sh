#!/bin/bash
tshark -i enp0s3 -w ~/scenario/DHCP/imn/both/client.pcap&



